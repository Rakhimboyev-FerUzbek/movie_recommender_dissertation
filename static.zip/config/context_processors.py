from config.translations import TRANSLATIONS


def ui_context(request):
    lang = request.session.get("site_language", "uz")
    if lang not in TRANSLATIONS:
        lang = "uz"

    return {
        "ui_lang": lang,
        "t": TRANSLATIONS[lang],
        "available_languages": [
            ("uz", "UZ"),
            ("ru", "RU"),
            ("en", "EN"),
        ],
    }