(function () {
    const storageKey = "site-theme";
    const body = document.body;
    const toggle = document.getElementById("themeToggle");

    function applyTheme(theme) {
        body.setAttribute("data-theme", theme);
        localStorage.setItem(storageKey, theme);

        if (toggle) {
            const label = toggle.querySelector(".theme-toggle-label");
            if (label) {
                label.textContent = theme === "dark" ? "Light Mode" : "Dark Mode";
            }
        }
    }

    const savedTheme = localStorage.getItem(storageKey) || "dark";
    applyTheme(savedTheme);

    if (toggle) {
        toggle.addEventListener("click", function () {
            const current = body.getAttribute("data-theme") || "dark";
            applyTheme(current === "dark" ? "light" : "dark");
        });
    }
})();