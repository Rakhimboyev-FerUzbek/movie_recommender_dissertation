from django import forms

from apps.movies.models import Genre


SORT_CHOICES = [
    ("", "Default"),
    ("title_asc", "Title A-Z"),
    ("title_desc", "Title Z-A"),
    ("rating_desc", "Rating High-Low"),
    ("year_desc", "Newest First"),
]


class MovieFilterForm(forms.Form):
    q = forms.CharField(required=False, label="Search")
    genre = forms.ModelChoiceField(
        queryset=Genre.objects.all(),
        required=False,
        empty_label="All Genres"
    )
    year = forms.IntegerField(required=False, label="Year")
    sort = forms.ChoiceField(required=False, choices=SORT_CHOICES)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        for name, field in self.fields.items():
            field.widget.attrs["class"] = "form-control"

        self.fields["q"].widget.attrs["placeholder"] = "Search movie title..."