from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from apps.users.models import UserProfile


class StyledFormMixin:
    def apply_bootstrap(self):
        for field_name, field in self.fields.items():
            css = "form-control"
            if isinstance(field.widget, forms.Textarea):
                css = "form-control form-textarea"
            field.widget.attrs.setdefault("class", css)
            field.widget.attrs.setdefault("placeholder", field.label or field_name.replace("_", " ").title())

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.apply_bootstrap()


class RegisterForm(StyledFormMixin, UserCreationForm):
    email = forms.EmailField(required=True, label="Email")
    first_name = forms.CharField(max_length=150, required=False, label="First name")
    last_name = forms.CharField(max_length=150, required=False, label="Last name")

    class Meta:
        model = User
        fields = (
            "username",
            "email",
            "first_name",
            "last_name",
            "password1",
            "password2",
        )

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("Bu email allaqachon ro'yxatdan o'tgan.")
        return email

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data["email"].strip().lower()
        user.first_name = self.cleaned_data.get("first_name", "").strip()
        user.last_name = self.cleaned_data.get("last_name", "").strip()
        if commit:
            user.save()
        return user


class UserUpdateForm(StyledFormMixin, forms.ModelForm):
    email = forms.EmailField(required=True, label="Email")

    class Meta:
        model = User
        fields = ("first_name", "last_name", "email")

    def __init__(self, *args, **kwargs):
        self.user_instance = kwargs.get("instance")
        super().__init__(*args, **kwargs)

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        qs = User.objects.filter(email__iexact=email)
        if self.user_instance:
            qs = qs.exclude(pk=self.user_instance.pk)
        if qs.exists():
            raise forms.ValidationError("Bu email boshqa foydalanuvchi tomonidan ishlatilgan.")
        return email


class UserProfileForm(StyledFormMixin, forms.ModelForm):
    preferred_genres_text = forms.CharField(
        required=False,
        help_text="Action, Drama, Comedy",
        label="Preferred genres"
    )

    class Meta:
        model = UserProfile
        fields = ("bio", "birth_year")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance and self.instance.preferred_genres:
            self.fields["preferred_genres_text"].initial = ", ".join(self.instance.preferred_genres)

    def clean_birth_year(self):
        birth_year = self.cleaned_data.get("birth_year")
        if birth_year is not None and (birth_year < 1900 or birth_year > 2100):
            raise forms.ValidationError("Tug'ilgan yil 1900 va 2100 oralig'ida bo'lishi kerak.")
        return birth_year

    def clean_preferred_genres_text(self):
        raw = self.cleaned_data.get("preferred_genres_text", "")
        items = [item.strip() for item in raw.split(",") if item.strip()]
        return items

    def save(self, commit=True):
        profile = super().save(commit=False)
        profile.preferred_genres = self.cleaned_data.get("preferred_genres_text", [])
        if commit:
            profile.save()
        return profile